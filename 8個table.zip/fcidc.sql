CREATE TABLE fcidc 
(
	IDCODE varchar2(11),
	RID varchar2(11),
	QID varchar2(2),
	BIRTHDT varchar2(8),
	FILLER varchar2(32),
	PRIMARY KEY(IDCODE)
)
