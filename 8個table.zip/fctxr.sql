CREATE TABLE fctxr 
(
	TXNDATE varchar2(8),
	TXNBRNO varchar2(4),
	EICODE varchar2(1),
	CURRCODE varchar2(3),
	ITEMCODE varchar2(2),
	SFLAG varchar2(1),
	EXCHGN varchar2(15),
	EXCHGA varchar2(15),
	DEPOSTN varchar2(15),
	DEPOSTA varchar2(15),
	OTHERN varchar2(15),
	OTHERA varchar2(15),
	TOTALN varchar2(15),
	TOTALA varchar2(15),
	TDNO1 varchar2(3),
	TDNO2 varchar2(3),
	TDNO3 varchar2(3),
	FILLER varchar2(44),
	PRIMARY KEY(TXNDATE, TXNBRNO, EICODE, CURRCODE, ITEMCODE, SFLAG)
)
