CREATE TABLE fcrpt 
(
	TXDATE varchar2(8),
	REPNO varchar2(5),
	SOURCE varchar2(2),
	BRNO varchar2(4),
	ITMNO varchar2(10),
	DTLNO varchar2(2),
	CURRCODE varchar2(3),
	COUNT varchar2(8),
	TXAMT varchar2(16),
	EXRATE varchar2(11),
	NOTE nvarchar2(20),
	FILLER varchar2(39),
	PRIMARY KEY(TXDATE, REPNO, SOURCE, BRNO, ITMNO, DTLNO, CURRCODE)
)